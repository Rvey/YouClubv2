<?php
// create a user Validator class to handle validation
// constructor which take in post form
// create methods to validate individual fields
// -- a method to validate a username
// a methode to validate an email
// return an error array once all checks are done


class UserValidation
{
    private $data;
    private $errors = [];
    private static $fields = ['username', 'email'];


    function __construct($post_data)
    {
        $this->data = $post_data;

    }

    // check what field are required
    public function validateForm()
    {
        foreach (self::$fields as $field) {
            // then put any validated username or email as a key in the data from the fields array
            if (!array_key_exists($field, $this->data)) {
                trigger_error("$field is not present in the data");
                return;
            }
        }
        // if the field doesnt exist so it gonna caring on , then we gonna create two method one for the username and other for the email
        // so we can check them next
        $this->validateUsername();
        $this->validateEmail();
        return $this->errors;
    }

    private function validateUsername()
    {
        // trim any spaces from the username key
        $val = trim($this->data['username']);
        //
        if (empty($val)) {
            $this->addError('username', 'username cannot be empty');
        } else {
            if (!preg_match('/^[a-zA-Z0-9]{6,12}$/', $val)) {
                $this->addError('username', 'username not valid');
            }
        }

    }



    private function validateEmail()
    {
        $val = trim($this->data['email']);

        if (empty($val)) {
            $this->addError('email', 'email cannot be empty');
        } else {
            if (!filter_var($val, FILTER_VALIDATE_EMAIL)) {
                $this->addError('email', 'email must be a valid email address');
            }
        }

    }

    private function addError($key, $val)
    {
        $this->errors[$key] = $val;
    }
}