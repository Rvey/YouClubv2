<?php
    require  ('UserValidation.php');
$errors = [];
  if(isset($_POST['submit'])){

//    echo 'form submitted';

  // validate entries
  $validation = new UserValidation($_POST);
  print_r( $error = $validation->validateForm());
  // save data to db
  }
?>

<html lang="en">
<head>
  <title>PHP OOP</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

  <div class="new-user">
    <h2>Create a new user</h2>
    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">

      <label>username: </label>
      <input type="text" name="username">

      <label>email: </label>
      <input type="text" name="email">

      <input type="submit" value="submit" name="submit">

    </form>
  </div>

</body>
</html>