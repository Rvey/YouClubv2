<?php
// classes
// classes are like blueprint of objects

//properties : username , email.
// methods : add friend , postStatus .
// private proprieties mean that we can access that only in the class and the class the we inherit from

class User {

    public $username ;
    protected $email;
    public $role = 'membre';

    public function __construct($username , $email){
        $this->username = $username;
        $this->email= $email;
        
    
    }

    // magic methode is the method that start with __
    // __decstruct mehtod
    public function __destruct(){
        echo "the user $this->username was removed <br/>";
    }


    public function messqge(){
        return "$this->email send a new message";
    }
    public function addFriend() {
        return "$this->email add new friend";
    }

    // getters
    public function getEmail(){
        return $this->email;
    }

    // setters
    public function setEmail($email){
            // chech if the email contain @ in it with the use of the strpros methode
            if (strpos($email , '@') > -1){
            $this->email = $email;
            }
    }

    }
    // inheritance - overriding properties & methods

    class adminUser extends User {
    public $level;
    public $role = 'admin';
    public function __construct($username, $email , $level)
    {
         $this->level = $level  ;
         // the parent keyword referred to the construct parent from the class we extend
        parent::__construct($username, $email);
    }
        public function messqge(){
            return "$this->email admin  send a new message";
        }

}

    $userOne = new User('regggd' , 'red@rederter.com');
    $userTwo = new User('ayoub' , 'ayoub@rederter.com');
    $userThree = new adminUser('red' ,'admin@sdf.com' , 3 );
//    unset($userOne);
    clone $userOne;



//    echo $userOne->username . '<br/>';
//    $userOne->setEmail('red@.com') . '<br/>';
//
//    echo $userOne->getEmail() . '<br/>';
//    echo $userTwo->getEmail() . '<br/>';
//    echo $userThree->level . '<br/>';

    // to know what class we are creating a new object from
    //echo 'the class is ' . get_class($userOne);
    // get_class_vars() get us all the proprities that are availble in that class

    //echo $userTwo->addFriend('yeet');

//echo $userOne->role . '<br/>';
//echo $userThree->role . '<br/>';
//echo $userOne->messqge() .  '<br/>' ;
//echo $userThree->messqge() . '<br/>';
