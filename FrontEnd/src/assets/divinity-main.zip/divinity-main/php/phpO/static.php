<?php
// the static method is a method that be access from the class directly and not via an instance of the class

class Weather
{
    private static $tempCondition = ['cold', 'mild', 'warm'];

    private static function cTof($c)
    {
        return $c * 9 / 5 * 32;
    }

    public static function determineTempCondition($f)
    {
        if ($f < 40) {
            // cold
            return self::$tempCondition[0];
    } else if ($f > 70) {
            return self::$tempCondition[1];
        } else {
            return self::$tempCondition[2];
        }
    }
}

// without using a static method
//$weatherInstance = new Weather();
//print_r($weatherInstance->tempCondition);

//print_r(Weather::$tempCondition);

//echo Weather::cTof(23);
echo Weather::determineTempCondition(66);