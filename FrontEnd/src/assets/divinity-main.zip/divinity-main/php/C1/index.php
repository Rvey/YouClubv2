
<?php
$age = [34 , 40 ,55] ;
$people = ['red' , 'lee' , 'chun'];
//print_r($age);

array_push($age , 60) ;
//print_r($age);
$merge = array_merge($age , $people);
//print_r($merge);

// associative array (key & value pairs)
// is key is kinda equivlent to the indent when we try to call something from an array
$redOne = ['shaun' => 'black' , 'mario' => 'orange' , 'red' => 'white'];
$redOne ['red'] = 'yellow';

//print_r($redOne);

//echo $redOne;

// count how much element in that array by using count()
//echo count($redOne);

// multidimension array
$blogs = [
    ['title' => 'mario party' , 'author' => 'mario' , 'content' => 'lorem' , 'score' => 30],
    ['title' => 'red party' , 'author' => 'red' , 'content' => 'hmmm' , 'score' => 40],
    ['title' => 'luigy party' , 'author' => 'luigi' , 'content' => 'yeet']
];

//echo $blogs[2]['title'];
//echo count($blogs[1]);

// remove the last array
$popped = array_pop($blogs);

//print_r($popped);

// foreach on multidimension array
foreach ($blogs as $blog) {
    echo $blog ['title'] . ' - '.  $blog ['author'] . ' <br/>';
}
?>




<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<?php foreach ($blogs as $blog){ ?>
<ul style="display: flex ; gap: 2em ; align-items: center ; justify-content: center">
     <h3><?php echo $blog['title'];?></h3>
     <h2><?php echo $blog ['score'];?></h2>

</ul>

<?php }?>

</body>
</html>