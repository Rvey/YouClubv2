<?php
//$file = 'text.txt' ;
//if (file_exists($file)){
//     // read file
//    echo readfile($file);
//
//    // copy file
//    copy($file,'quotes.txt');
//
//    // file size
//    echo filesize($file);
//}
//
//else {
//    echo ' file doesnt exist';
//}
//
//// make directory
//mkdir('name of the directory we want to make');


// classes
class User {

    public $email;
    public $name;
// construct function is special type of function that runs whatever we instantiate a class
// and then that construct function  can set some initial values to our variables
    public function __construct($name ,$email){

//        $this->name = 'red@gmail.com';
//        $this->name = ' RedOne';

        // so instead of hardcoded it like above we gonna set the parameters as the values to reserve the input values
        $this->email = $email;
        $this->name = $name;

    }

    public function login(){
        echo 'Hello' . $this->name  ;
    }

}
// creating new object from the class  and store it in the variable and that what we call it instantiating  a class
//$userOne = new User();
// and the we use that variable to access what is inside the function in this case we access the login function
//$userOne->login();
//echo $userOne->name;

$userTwo = new User('ayoub ' , 'ayoub@gmail.com');
echo $userTwo->name;
echo $userTwo->email;

// we need to instantiate the login function in order for the constuct method to work and fires the login function
$userTwo->login();