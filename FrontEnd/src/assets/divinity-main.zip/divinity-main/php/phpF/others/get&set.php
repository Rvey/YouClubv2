<?php

// classes
class User
{
// private so we cant access them outside that class
    private $email;
    private $name;
// construct function is special type of function that runs whatever we instantiate a class
// and then that construct function  can set some initial values to our variables
    public function __construct($name, $email)
    {

//        $this->name = 'red@gmail.com';
//        $this->name = ' RedOne';

        // so instead of hardcoded it like above we gonna set the parameters as the values to reserve the input values
        $this->email = $email;
        $this->name = $name;

    }

    public function login()
    {
        echo 'Hello' . $this->name;
    }

    // this a public function that return a value while accessing the private property inside that class
    public function getName()
    {
        return $this->name;
    }

    // function to update the name
    public function setName($name){
//        return $this->name;
        //we check here if the name a string
        if (is_string($name) && strlen($name) > 2){
            // access the name to see if it met our rule
            $this->name = $name;
            return "name has been updated to $name";
        }else {
            return 'not a valid name';
        }



    }


}

$userTwo = new User('yeyeyeyeye', 'ayoub@gmail.com');

//echo $userTwo->getName();
echo $userTwo->setName('red');