<?php
// super globals
//$_POST['name'] , $_GET['name']

echo $_SERVER['SERVER_NAME'] . '<BR />' ;

ECHO $_SERVER['REQUEST_METHOD']. '<BR />' ;

echo $_SERVER['SCRIPT_FILENAME']. '<BR />';
echo $_SERVER['PHP_SELF']. '<BR />';