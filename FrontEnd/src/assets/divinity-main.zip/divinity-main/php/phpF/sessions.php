<?php
// sessions
//  session variable solve the problem of storing information and know who you are so it dolve the problem of storing information to be used multiple pages (username , favorite , color ) by default , sessions variable last until the user closes the browser
// so session variable hold information about one single user in that session and are avaible to all pages in one application


// the session store data between loading deferent pages 


if (isset($_POST['submit'])){
    session_start();
    // we storing what we get from the user name input
    $_SESSION['user'] = $_POST['user'];
//    echo  $_SESSION['user'] . ' session';
    header('Location: add.php');
}
if (isset($_POST['logout'])){
    session_unset();
   echo 'logout' ;
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>session</title>
</head>
<body>
<form action="<?php echo $_SERVER['PHP_SELF'] ?>"  METHOD="post">
    <input type="text" name="user">
    <input type="submit" name="submit" value="submit">
    <input type="submit" name="logout" value="logout">
</form>

</body>
</html>
