<?php

// to protect from sql injection to protect from sata base
// $conn the connection we store into
// $_POST['name']) the data we getting fro; the user

//    $conn = mysqli_connect('localhost', 'root', '', 'pizza');

$email = mysqli_real_escape_string($conn, $_POST['email']);
$name = mysqli_real_escape_string($conn, $_POST['name']);
$Ingredients = mysqli_real_escape_string($conn, $_POST['Ingredients']);
// create sql
$sql = "insert into pizzas (email,name,Ingredients) values ('$email' , '$name' , '$Ingredients')";
?>