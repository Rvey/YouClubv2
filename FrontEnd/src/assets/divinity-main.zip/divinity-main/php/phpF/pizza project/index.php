<?php

include('dbconnect.php');

// write aura for all pizza
//constructed the query string using select and from
$sql = 'SELECT id , name , email , Ingredients  FROM pizzas';

// make query and get result
// we store that query that we making via this connection so we know what data base we connecting to and we issuer in the sql command and that should get us the data from that table   in the result variable
$result = mysqli_query($conn, $sql);

// fetch the resulting rows as an array
// the mysqli_ASSOC mode  return the what in the result variable  as associative array
$pizzas = mysqli_fetch_all($result, MYSQLI_ASSOC);

// free the result from the memories
//mysqli_free_result($result);


// close the connection to the database


$close = mysqli_close($conn);
if ($close) {

//    print_r($pizzas);
//    echo 'connection closed';
}


// covert string separated by comma to array so we can cycle through it
//print_r(   explode(',' , $pizzas[1]['ingredients']));


?>
<?php include('template/header.php'); ?>

<h2 class="text-center">pizzas</h2>

<div class="container text-center">
    <div class="row">
        <?php foreach ($pizzas as $pizza) : ?>
            <div class="card" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title">pizza <?php echo htmlspecialchars($pizza['id']); ?></h5>
                    <p class="card-text">Email : <?php echo htmlspecialchars($pizza['name']); ?></p>
                    <!--                    <p class="card-text">Ingredients : -->
                    <ul style="list-style: none">
                        <?php foreach(explode(',', $pizza['Ingredients']) as $ing): ?>
                        <li> <?php echo $ing ?> </li>
                       <?php endforeach;?>
                    </ul>



<!--                    <ul> --><?php //foreach (explode(',', $pizzas['Ingredients']) as $ing): ?>
<!---->
<!--                            <li> --><?php //echo htmlspecialchars($ing) ?><!-- </li>-->
<!---->
<!--                        --><?php //endforeach; ?>
<!--                    </ul>-->

                    <a href="details.phpd=<?php echo $pizza['id'] ?>" class="btn btn-primary">More info</a>
                </div>
            </div>

        <?php endforeach; ?>

        <?php if(count($pizzas) >= 2) : ?>
        <p>theres more than 3 pizzas</p>
        <?php else : ?>
        <p>there is less than 3 pizzas</p>

        <?php endif; ?>

    </div>
</div>
<?php include('template/footer.php'); ?>
