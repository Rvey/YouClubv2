
<?php
// connct to the basebase
$conn = mysqli_connect('localhost', 'root', '', 'pizza');

// check the connection
if (!$conn) {
    // the connct_error function is to show the specific error
    echo 'connction error : ' . mysqli_connect_error();
}

?>