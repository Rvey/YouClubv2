<?php

// check email

if (empty($_POST['email'])) {
    $error['email'] = 'An email is required';

} else{
    $email = $_POST['email'];
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error['email'] = 'the email is not valide';
    }
}

// check name

$nameCheck = '/^[a-zA-Z\s]+$/';
if (empty($_POST['name'])) {
    $error['name'] = 'name is required';
}

else{
    $name = $_POST['name'];
    if (!preg_match($nameCheck,$name)) {

        $error['name'] = 'the name is not correct ';
    }

}

// check ing

$ingCheck = '/^([a-zA-Z\s]+)(,\s*[a-zA-Z\s]*)*$/';
if (empty($_POST['Ingredients'])) {
    $error['Ingredients'] = 'An ing is required';
}
else{
    $Ingredients = $_POST['Ingredients'];
    if (!preg_match($ingCheck, $Ingredients)) {
        $error['Ingredients'] = 'the ingredient is not valid ';
    }

}

?>