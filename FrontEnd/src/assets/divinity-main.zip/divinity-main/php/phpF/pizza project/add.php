<?php

include('dbconnect.php');

// error handle - remain the valid input after the submit so the user don't have to re enter everything

$name = $email = $Ingredients = '';
$error = ['email' => '', 'name' => '', 'Ingredients' => ''];


if (isset($_POST['submit'])) {

    include('checkinput.php');

//end of the POST check


// redirect the user if the form is valid
// array filter is a function that cycle through the $errors array in our case to check if theres any error inside it
if (array_filter($error)) {
    // we use the header to redirect the user to an other page
//    echo 'theres error in the form';
}else{

    include('insert.php');

    // save it to the db and check
    if (mysqli_query($conn, $sql)) {
        // success
        header('Location: index.php');
    }else {
        echo ' query error: ' . mysqli_error($error);
    }
}
}
?>

<?php include('template/header.php'); ?>

<section class="'container grey-text">
    <h4 class="text-center">add a pizza</h4>
    <form class="d-flex flex-column px-5 " action="add.php" method="POST">
        <label for="">Your Email :</label>
         <!-- echo the value of the name from the POST methode of that input to remain the valid input after the form is submitted -->
        <input type="email" name="email" value="<?php echo $email ?>">
        <div class="text-danger"><?php echo $error['email'] ?></div>
        <label for="">Your name :</label>
        <input type="text" name="name" value="<?php echo $name ?>">
        <div class="text-danger"><?php echo $error['name'] ?></div>
        <label for="">Ingredients (comma separated):</label>
        <input type="text" name="Ingredients" value=" <?php echo $Ingredients ?>">
        <div class="text-danger"><?php echo $error['Ingredients'] ?></div>
        <div class="text-center">
            <input type="submit" name="submit" value="submit" class="btn btn-primary">
        </div>
    </form>

</section>


<?php include('template/footer.php'); ?>

