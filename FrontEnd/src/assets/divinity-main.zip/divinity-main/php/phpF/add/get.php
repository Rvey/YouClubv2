<?php
//// form validation  - get post -
//
//// the isset function check if certain value has been set
//// the $_GET is a global array that we store on the server  in this get variable what ever data we got in the form like email , name ...
//// the same as $_POST just the post is passing the data in header which is hidden and more secure not like the get which is pass it in the url
//
//
//// then we add the we gonna check if the submit btn is checked which is gonna be referred to by ['the name of the input we wanna check if its clicked']
//// before the click on the submit the submit it self have no value in the get array but when the click if hit it gonna have value then the isset works and fires what inside the if statement
//
////if (isset($_GET['submit'])){
////echo $_GET['email'] .  '<br/>';
////echo $_GET['name'] .  '<br/>';
////    echo $_GET['Ingredients'];
////}
//
//// the htmlspecialchars convert any special script characters that can be dangerous script to html characters
//// for example therese that dangerous script like windows.script.location.dangerwebsite its htmlspecialchars not gonna let that script run instead when it gonna get back to the browser is gonna shows as string
//if (isset($_POST['submit'])) {
////    echo htmlspecialchars($_POST['email'] .  '<br/>');
////    echo htmlspecialchars($_POST['name'] .  '<br/>');
////    echo htmlspecialchars($_POST['Ingredients'] .  '<br/>');
//
//
//    // form validation
//    // check email
//    if (empty($_POST['email'])) {
//        echo 'An email is required <br/>';
//    } else {
////        echo htmlspecialchars($_POST['email'] .  '<br/>');
//        // RegEx
//        $email = $_POST['email'];
//        // THE filter_var is a build in function into php that filter and we use FILTER_VALIDATE_EMAIL to describe what kind of filter we want  of the email only and for the other check we use regex cuz the php doesnt has one
//
//        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
//            echo 'the email is not valide';
//        }
//
//    }
//
//
//    // check email
//    if (empty($_POST['name'])) {
//        echo 'An name is required <br/>';
//    } else {
////        echo htmlspecialchars($_POST['name'] .  '<br/>');
//
//        // check name
//        $name = $_POST['name'];
//        $nameCheck = '/^[a-zA-Z\s]+$/';
//        // the preg match is what we use to match something to regular expresion
//        if (!preg_match($nameCheck, $name)) {
//            echo 'the name is not correct ';
//        }
//
//    }
//
//
//    // check email
//    if (empty($_POST['Ingredients'])) {
//        echo 'An ing is required <br/>';
//    } else {
////        echo htmlspecialchars($_POST['Ingredients'] . '<br/>');
//        $ing = $_POST['Ingredients'];
//        $ingCheck = '/^([a-zA-Z\s]+)(,\s*[a-zA-Z\s]*)*$/';
//        if (!preg_match($ingCheck , $ing)){
//            echo 'the ingredient is not valid ';
//        }
//    }
//
//}
////end of the post check
//
//
//?>
<!---->
<!---->
<!---->
<?php //include('../template/header.php'); ?>
<!---->
<!--<section class="'container grey-text">-->
<!--    <h4 class="text-center">add a pizza</h4>-->
<!--    <!-- what file is gonna handle that form in the server or do something with it and that what action attribute is for -->-->
<!--    <form class="d-flex flex-column px-5 " action="get.php" method="POST">-->
<!--        <label for="">Your Email :</label>-->
<!--        <input type="email" name="email">-->
<!--        <label for="">Your name :</label>-->
<!--        <input type="text" name="name">-->
<!--        <label for="">Ingredients (comma separated):</label>-->
<!--        <input type="text" name="Ingredients">-->
<!--        <div class="text-center pt-4">-->
<!--            <input type="submit" name="submit" value="submit" class="btn btn-primary">-->
<!--        </div>-->
<!--    </form>-->
<!--</section>-->
<!---->
<!---->
<?php //include('../template/footer.php'); ?>
<!---->
