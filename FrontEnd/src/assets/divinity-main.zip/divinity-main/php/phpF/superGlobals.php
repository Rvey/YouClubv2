<?php
// super globals
//$_POST['name'] , $_GET['name']

echo $_SERVER['SERVER_NAME'] . '<BR />' ;