const addForm = document.querySelector(".add");
const deleteForm = document.querySelector(".delete");
const list = document.querySelector(".todos");
const search = document.querySelector(".search input");

const generateTemplate = (todo) => {
  const html = `<li class=" list-group-item d-flex justify-content-between align-item-center">
<span>${todo}</span>
<i class="far fa-trash-alt delete"></i>
</li>`;

  list.innerHTML += html;
};

// get the field
addForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const todo = addForm.add.value;

  if (todo.length >= 3) {
    generateTemplate(todo);
    addForm.classList.remove("bg-danger");

    addForm.reset();
  } else if (todo.length <= 2) {
    addForm.classList.add("bg-danger");
  }

  // console.log(todo.trim())
});

// delte todos
list.addEventListener("click", (e) => {
  if (e.target.classList.contains("delete")) {
    e.target.parentElement.remove();
  }
});



// search filter function
const filterTodos = (input) => {
    
  Array.from(list.children)
    .filter((todo) => !todo.textContent.toLowerCase().includes(input))
    .forEach((todo) => todo.classList.add("filtered"));

    Array.from(list.children)
    .filter((todo) => todo.textContent.toLowerCase().includes(input))
    .forEach((todo) => todo.classList.remove("filtered"));

};


search.addEventListener("keyup", (e) => {
    // fix the search when cap 
  const input = search.value.trim().toLowerCase();
  // console.log(input)
  filterTodos(input);
});
