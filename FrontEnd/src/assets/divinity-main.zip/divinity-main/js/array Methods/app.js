// const scores = [23 ,45 , 50 , 80] ;

// // filter methode 
// const FilteredScore = scores.filter((score) => {
//   return score > 50 ;
// })

// console.log(FilteredScore)


const users = [
  {name: 'shaun' , premium: true} ,
  {name: 'red' , premium: false} ,
  {name: 'mario' , premium: false} ,
  {name: 'chun-li' , premium: true} 
]

// const filteredUser = users.filter(user => {
//   return user.premium === false  ;
// })

const filteredUser = users.filter(user => user.premium);

console.log(filteredUser)