let form = document.querySelector('.form')
let submit = document.querySelector('.submit')
let patern = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
let username = document.querySelector('#username')

let feedback = document.querySelector('.feedback');

// regEx  in action


form.addEventListener('submit' , e => {
e.preventDefault();

    let feedback = document.querySelector('.feedback');
    let username = document.querySelector('#username').value;


    
    if(patern.test(username)){
        feedback.textContent = 'the username is valid ' ; 
        
    }
    else{
        feedback.textContent = 'the username is not valid' ; 
    }


})



// live feedback 
form.username.addEventListener('keyup' , e => {
      // to see the event 
    console.log(e)


    let yeet = e.target.altKey ;

if(yeet = true){
    // preload()
    feedback.textContent = 'alt key is pressed ';
    yeet.forEach(element => {
        element.form.setAttribute('class' , 'moveR')
    });
  

  

  


}

    if(patern.test(e.target.value)){
 
  // we created the class success in css  and attacket to the username input with the setAttribute 
      username.setAttribute('class' , 'success')
    }else{
        username.setAttribute('class' , 'failed')
    }
})










