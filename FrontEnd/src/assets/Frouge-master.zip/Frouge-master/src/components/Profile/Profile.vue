<template>



    <div class="flex mx-12 flex-wrap xl:flex-nowrap">
      <div class=" flex flex-col items-center w-full xl:w-8/12 ">
        <div class="section1 flex flex-col justify-center">
          <!-- background -->
          <div class="">
            <img
              src="../../assets/science.png"
              alt=""
              class="background rounded-xl"
            />
          </div>
          <div class="flex flex-col ">
            <!-- profilepic -->
            <div class="flex">
              <label
                class="w-44 h-44 flex flex-col items-center px-4 py-6  text-blue tracking-wide uppercase border cursor-pointer  hover:text-red-400 relative bottom-20 right-0 rounded-full border-none"
              >
                <img
                  src="../../assets/logo.png"
                  class="bg-green-500 rounded-full border-4  border-white relative bottom-2 right-0 z-30"
                />
                <input type="file" class="hidden" />
              </label>
              <div class="px-9 py-5 space-y-2 ">
                <h1 class="font-semibold text-gray-800">Redouane bouabana</h1>
                <h2 class="text-gray-700 text-sm">Full Stack Web Developer</h2>
                <button
                  class="bg-red-500 px-4 py-1 font-medium text-white rounded-md"
                >
                  Ping
                </button>
              </div>
            </div>
          </div>
          <div class=" about space-y-3  p-3 rounded-md ">
            <h1 class="font-bold text-xl">About Me</h1>
            <p class="px-3">
              Lorem ipsum dolor sit amet consectetur adipisicing elit.
              Dignissimos vel mollitia, quam eos dolor numquam consequatur
              natus, est distinctio iste pariatur obcaecati. Atque nemo pariatur
              laudantium, corrupti et illo? Obcaecati repellat, qui sequi iure
              dicta sit molestiae rem fugit. Dicta quo temporibus similique
              accusamus ducimus minus magni quam, quidem maxime.
            </p>
            <div class="flex justify-end p-3">
              <button
                class="bg-indigo-400 px-3 py-2 text-white rounded-md font-medium"
              >
                edit
              </button>
            </div>
          </div>

          <h1 class="font-semibold text-3xl pt-10  pb-8 ">Saved Posts</h1>

          <div class="flex flex-wrap gap-9 justify-start mb-24">
            <div class="w-60 bg-gray-100 rounded-md">
              <div>
                <img
                  src=""
                  alt=""
                  srcset=""
                  class="bg-indigo-400 w-56 h-10 m-2"
                />
                <h1 class="m-2">lorem ipsum dolor</h1>
              </div>
            </div>
            <div class="w-60 bg-gray-100 rounded-md">
              <div>
                <img
                  src=""
                  alt=""
                  srcset=""
                  class="bg-indigo-400 w-56 h-10 m-2"
                />
                <h1 class="m-2">lorem ipsum dolor</h1>
              </div>
            </div>
            <div class="w-60 bg-gray-100 rounded-md">
              <div>
                <img
                  src=""
                  alt=""
                  srcset=""
                  class="bg-indigo-400 w-56 h-10 m-2"
                />
                <h1 class="m-2">lorem ipsum dolor</h1>
              </div>
            </div>
            <div class="w-60 bg-gray-100 rounded-md">
              <div>
                <img
                  src=""
                  alt=""
                  srcset=""
                  class="bg-indigo-400 w-56 h-10 m-2"
                />
                <h1 class="m-2">lorem ipsum dolor</h1>
              </div>
            </div>
            <div class="w-60 bg-gray-100 rounded-md">
              <div>
                <img
                  src=""
                  alt=""
                  srcset=""
                  class="bg-indigo-400 w-56 h-10 m-2"
                />
                <h1 class="m-2">lorem ipsum dolor</h1>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="w-full xl:w-1/5  rounded-md space-y-3">
        <h1 class="font-semibold text-3xl pt-10  pb-5 block xl:hidden">
          Extra
        </h1>
        <div class="space-y-4 pl-7 bg-gray-100 py-5 rounded-xl">
          <h1 class="font-bold text-xl">Connection</h1>
          <ul class="space-y-2">
            <li><a href="#" class="font-semibold">Github</a></li>
            <li><a href="#" class="font-semibold">Twitter</a></li>
            <li><a href="#" class="font-semibold">Discord</a></li>
          </ul>
        </div>
        <div class="space-y-4 pl-7 bg-gray-100 py-5 rounded-xl">
          <h1 class="font-bold text-xl">Achievement</h1>
          <ul class="space-y-2">
            <li class="font-semibold">344 Posts</li>
            <li class="font-semibold">344 Posts</li>
            <li class="font-semibold">344 Posts</li>
          </ul>
        </div>
      </div>
    </div>

</template>
<style>
.background {
  object-fit: cover;
  width: 80em;
  height: 250px;
}
.section1 {
  width: inherit;
}
.about {
  background-color: rgba(238, 238, 238, 0.363);
}

</style>
