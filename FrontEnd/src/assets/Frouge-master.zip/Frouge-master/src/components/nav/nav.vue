<template>
  <header
    class="text-gray-600 body-font fixed top-0 left-0 w-full  z-50 shadow-md"
  >
    <div
      class="container mx-auto flex flex-wrap p-5 flex-col md:flex-row items-center "
    >
      <nav class="flex lg:w-2/5 flex-wrap items-center text-base md:ml-auto">
        <router-link class="mr-5 hover:text-red-400 hover:pb-3" to="/"
          >Home</router-link
        >
        <router-link class="mr-5 hover:text-gray-900" to="/Community"
          >Community</router-link
        >
        <router-link class="mr-5 hover:text-gray-900" to="/Dashboard"
          >Dashboard</router-link
        >
       <router-link class="mr-5 hover:text-gray-900" to="/Profile"
          >Profile</router-link
        >
      </nav>
      <a
        class="flex order-first lg:order-none lg:w-1/5 title-font font-medium items-center text-gray-900 lg:items-center lg:justify-center mb-4 md:mb-0"
      >
        <svg
          class="w-6 h-6"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            stroke-linecap="round"
            stroke-linejoin="round"
            stroke-width="2"
            d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"
          ></path>
        </svg>
        <span
          class="ml-3 text-xl bg-clip-text text-transparent bg-gradient-to-r from-red-300 to-red-500 font-bold"
          >YouClub</span
        >
      </a>
      <div class="lg:w-2/5 flex gap-3 lg:justify-end ml-5 lg:ml-0">
        <router-link
          class="inline-flex items-center bg-gray-200 border-0 py-1 px-3 focus:outline-none hover:bg-gray-200 rounded text-base mt-4 md:mt-0"
          to="/Login"
          >Login</router-link
        >
        <router-link
          class="inline-flex items-center bg-gray-200 border-0 py-1 px-3 focus:outline-none hover:bg-gray-200 rounded text-base mt-4 md:mt-0"
          to="/Register"
          >Register</router-link
        >
      </div>
    </div>
  </header>
</template>

<script>
export default {
  name: "nav",
  props: {},
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
header {
  background: rgba(250, 252, 252, 0.664);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(9.5px);
  -webkit-backdrop-filter: blur(9.5px);
  border: 1px solid rgba(255, 255, 255, 0.18);
}
</style>
