<template>
  <Modal v-if="modalOpen" :modalContent="modalContent" @close="handleClose()" />

  <div
    class="flex flex-col justify-center mx-14  md:mx-32 lg:mx-40 xl:mx-72 gap-20 flex-wrap w-auto "
  >
    <div class=" flex greet rounded-3xl my-8 justify-center w-full">
      <div
        class=" bg-gradient-to-r from-green-100 via-red-500 to-red-300 flex items-center justify-between h-14 rounded-full w-full"
      >
        <div>
          <h1 class="text-white pl-10 text-xl">welcome Redone</h1>
        </div>
        <div>
          <img class="w-48" src="../../assets/programmer-animate.svg" alt="" />
        </div>
      </div>
    </div>

    <!-- search  -->
    <div class="flex items-center gap-4 mx-2 xl:mx-9 md:mx-6  ">
      <div class="flex flex-col  bg-red-300 rounded-xl w-full ">
        <div class=" m-2 flex items-center gap-3 focus-within:text-gray-600">
          <input
            type="text"
            class="p-3 w-full rounded-md outline-none "
            placeholder="Search anything .. "
          />
          <button
            class="px-4 py-3 rounded-md text-gray-700 text-md font-bold tracking-wider "
          >
            search
          </button>
        </div>
      </div>

      <div>
        <button @click="openModal('SubmitPostModal')">Post</button>
      </div>
    </div>
  </div>
</template>
<script>
import Modal from "@/components/Misc/Modal.vue";
import { ref } from "vue";
export default {
  components: {
    Modal,
  },

  setup() {
    const modalOpen = ref(false);
    const modalContent = ref("");

    const handleClose = () => {
      modalOpen.value = false;
    };

    const openModal = (modal) => {
      modalContent.value = modal;
      modalOpen.value = true;
    };

    return {
      modalOpen,
      handleClose,
      openModal,
      modalContent,
    };
  },
};
</script>
<style></style>
