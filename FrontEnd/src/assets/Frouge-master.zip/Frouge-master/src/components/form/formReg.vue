<template>
  <div class="page flex w-screen h-screen ">

    
    <div class="  md:w-2/5 "></div>
    <div class=" form  rounded-xl p-6 m-3 md:w-3/5 w-full">
    <div class="text-center ">
    <h1 class="font-bold text-3xl tracking-wider pb-3">Welcome Back!</h1>
    <h3>We're so exicited to see you again!</h3>
    </div>
    
      <form class="flex flex-col justify-center  " method="POST" action="#">
           <div class="mb-6 pt-3 rounded ">
          <label
            class=" block text-gray-700 text-sm font-semibold tracking-wide mb-2 ml-3"
            for="email"
            >Full Name</label
          >
          <input
            type="text"
            class="bg-white bg-opacity-0 w-full text-gray-700 focus:outline-none border-b-4 border-red-300 focus:border-red-500 transition duration-500 px-3 pb-3"
          />
        </div>
         <div class="mb-6 pt-3 rounded ">
          <label
            class=" block text-gray-700 text-sm font-semibold tracking-wide mb-2 ml-3"
            for="email"
            >Username</label
          >
          <input
            type="text"
            class="bg-white bg-opacity-0 w-full text-gray-700 focus:outline-none border-b-4 border-red-300 focus:border-red-500 transition duration-500 px-3 pb-3"
          />
        </div>
        <div class="mb-6 pt-3 rounded ">
          <label
            class=" block text-gray-700 text-sm font-semibold tracking-wide mb-2 ml-3"
            for="email"
            >Email</label
          >
          <input
            type="email"
            class="bg-white bg-opacity-0 w-full text-gray-700 focus:outline-none border-b-4 border-red-300 focus:border-red-500 transition duration-500 px-3 pb-3"
          />
        </div>
        <div class="mb-6 pt-3 rounded ">
          <label
            class="block text-gray-700 text-sm font-semibold mb-2 ml-3 tracking-wide"
            for="password"
            >Password</label
          >
          <input
            type="password"
            class="bg-white bg-opacity-0  w-full text-gray-700 focus:outline-none border-b-4 border-red-300 focus:border-red-500  transition duration-500 px-3 pb-3"
          />
        </div>
           <div class="mb-6 pt-3 rounded ">
          <label
            class="block text-gray-700 text-sm font-semibold mb-2 ml-3 tracking-wide"
            for="password"
            >Confirm Password</label
          >
          <input
            type="password-confirmation"
            class="bg-white bg-opacity-0  w-full text-gray-700 focus:outline-none border-b-4 border-red-300 focus:border-red-500  transition duration-500 px-3 pb-3"
          />
        </div>
        <div class="flex justify-between flex-wrap">
          <router-link
            to="/Register"
            class="text-sm font-medium text-gray-800 hover:text-gray-900 hover:underline mb-6"
            >Forgot your password?</router-link
          >
          <router-link
            to="/Register"
            class="text-sm font-medium text-gray-800 hover:text-gray-900 hover:underline mb-6"
            >Don't have an account?</router-link
          >
        </div>
        <button
          class="font-karla bg-gradient-to-r from-red-400 to-red-500 hover:bg-purple-700 text-white font-bold py-2 rounded shadow-lg hover:shadow-xl transition duration-200 tracking-wider"
          type="submit"
        >
          Sign In
        </button>

      

        <router-link
          to="/"
          class="mt-4
          flex gap-2 items-center hover:underline hover:text-red-700 font-semibold"
        >
          <svg
            class="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M7 16l-4-4m0 0l4-4m-4 4h18"
            ></path>
          </svg>
          Home</router-link
        >

      </form>
      
    </div>
  </div>


</template>
<script>
import s from "./form.module.scss";
export default {
  setup() {
    return {
      s,
    };
  },
};
</script>

<style lang="scss">
.page {
  height: 100vh;
  background: url("../../assets/science.png");
}
</style>