<template>
  <div class="w-full shadow-md z-10">
    <nav
      class=" flex justify-between mx-12 h-16 items-center md:mx-36 lg:mx-44 "
    >
      <div>logo</div>

      <div class="gap-9 h-16 items-center hidden md:flex">
        <router-link class=" hover:text-red-400" to="/">Home</router-link>
        <router-link class=" hover:text-gray-900" to="/Community"
          >Community</router-link
        >

        <router-link class=" hover:text-gray-900" to="/Dashboard"
          >Dashboard</router-link
        >
        <router-link class=" hover:text-gray-900" to="/BlogPost"
          >Post</router-link
        >
      </div>
      <transition name="fade">
        <div class="flex gap-5">
          <div class=" inline-block relative">
            <!-- profile btn -->

            <button
              class="font-semibold py-2 rounded inline-flex items-center"
              @click="show()"
            >
              <svg
                class="w-7 h-7"
                fill="currentColor"
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fill-rule="evenodd"
                  d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-6-3a2 2 0 11-4 0 2 2 0 014 0zm-2 4a5 5 0 00-4.546 2.916A5.986 5.986 0 0010 16a5.986 5.986 0 004.546-2.084A5 5 0 0010 11z"
                  clip-rule="evenodd"
                ></path>
              </svg>
            </button>

            <!-- menu btn -->
            <button
              class="font-semibold py-2  rounded inline-flex items-center  md:hidden "
            >
              <div class="">
                <svg
                  class="w-7 h-7"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fill-rule="evenodd"
                    d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM9 15a1 1 0 011-1h6a1 1 0 110 2h-6a1 1 0 01-1-1z"
                    clip-rule="evenodd"
                  ></path>
                </svg>
              </div>
            </button>

            <!-- dropdown menu -->

            <div
              v-show="isOpen"
              class="absolute right-0 mt-2 py-2 w-48 bg-gray-100 rounded-md font-semibold "
            >
              <router-link
                to="/Profile"
                class="block px-4 py-2 text-md capitalize text-gray-700 hover:bg-red-500 hover:text-white"
              >
                My Profile
              </router-link>
              <router-link
                to=""
                href="#"
                class="block px-4 py-2 text-md capitalize text-gray-700 hover:bg-red-500 hover:text-white"
              >
                Sign Out
              </router-link>
            </div>
          </div>
        </div>
      </transition>
    </nav>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isOpen: false,
    };
  },
  methods: {
    show() {
      this.isOpen = !this.isOpen;
    },
  },
};
</script>
<style scoped>
.fade-enter-from {
  opacity: 0;
}
.fade-enter-to {
  opacity: 1;
}
.fade-enter-active {
  transition: all 2s ease;
}
</style>
