<template>
  <div class="whitespace"></div>
</template>

<script>
export default {
  name: "Whitespace",
  setup() {},
};
</script>

<style lang="scss">
.whitespace {
  aspect-ratio: 31 / 2;
}
</style>
