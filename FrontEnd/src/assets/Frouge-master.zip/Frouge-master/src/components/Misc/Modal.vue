<template>
  <div :class="styles.overlay">
    <div :class="styles.modal">
      <component :is="modalContent" @close="$emit('close')"></component>
    </div>
  </div>
</template>

<script>
import { onMounted, onUnmounted } from "@vue/runtime-core";
import styles from "./Modal.module.scss";

import SubmitPostModal from "@/components/Modals/SubmitPostModal/SubmitPostModal.vue";

export default {
  name: "Modal",
  props: ["modalContent"],
  components: {
    SubmitPostModal,
  },
  setup() {
    onMounted(() => {
      document.body.classList.add("no-scroll");
    });

    onUnmounted(() => {
      document.body.classList.remove("no-scroll");
    });

    return { styles };
  },
};
</script>
