<template>
  <div class=" w-full gap-11 flex justify-center items-center">
    <div>
      <!--posts section -->

      <div class=" flex flex-wrap justify-center gap-5 ">
    <div class="mx-2">
          <div
            class="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden md:max-w-3xl "
          >
            <div class="md:flex m-2 ">
              <div class="md:flex-shrink-0">
                <img
                  class="h-48 w-full object-cover md:h-full md:w-48 bg-green-100 rounded-md "
                  src="/programmer-animate.svg"
                  alt="hehe"
                />
              </div>
              <div class="flex flex-col  ">
                <div class="p-5">
                  <p
                    class="tracking-wide text-white px-2 py-1  flex justify-center items-center w-max bg-red-400 rounded-xl text-xs mb-5"
                  >
                    subject tag
                  </p>

                  <h3
                    href="#"
                    class="block mt-1 text-lg leading-tight font-medium text-black hover:underline"
                  >
                    Subject title
                  </h3>
                  <p class="mt-2 text-gray-500 max-w-prose">
                    Getting a new business off the ground is a lot of hard work.
                    Here are five ideas you can use to find your first
                    customers.
                  </p>
                </div>
                <div class="flex gap-4 justify-end  p-5 items-center">
                  <router-link to="/BlogPost"
                    class="bg-indigo-400 py-2 px-3 rounded-md shadow-md font-semibold text-white hover:bg-indigo-600"
                  >
                    Read More
                  </router-link>

                  <button>
                    <svg
                      class="w-6 h-6"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 4a2 2 0 012-2h6a2 2 0 012 2v14l-5-2.5L5 18V4z"
                        class="hover:text-red-300 cursor-pointer "
                      ></path>
                    </svg>
                  </button>

                  <button>
                    <svg
                      class="w-6 h-6"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z"
                        class="hover:text-blue-300 cursor-pointer "
                      ></path>
                    </svg>
                  </button>
                  <div>
                    44
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
          <div class="mx-2">
          <div
            class="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden md:max-w-3xl "
          >
            <div class="md:flex m-2 ">
              <div class="md:flex-shrink-0">
                <img
                  class="h-48 w-full object-cover md:h-full md:w-48 bg-green-100 rounded-md "
                  src="/programmer-animate.svg"
                  alt="hehe"
                />
              </div>
              <div class="flex flex-col  ">
                <div class="p-5">
                  <p
                    class="tracking-wide text-white px-2 py-1  flex justify-center items-center w-max bg-red-400 rounded-xl text-xs mb-5"
                  >
                    subject tag
                  </p>

                  <h3
                    href="#"
                    class="block mt-1 text-lg leading-tight font-medium text-black hover:underline"
                  >
                    Subject title
                  </h3>
                  <p class="mt-2 text-gray-500 max-w-prose">
                    Getting a new business off the ground is a lot of hard work.
                    Here are five ideas you can use to find your first
                    customers.
                  </p>
                </div>
                <div class="flex gap-4 justify-end  p-5 items-center">
                  <router-link to="/BlogPost"
                    class="bg-indigo-400 py-2 px-3 rounded-md shadow-md font-semibold text-white hover:bg-indigo-600"
                  >
                    Read More
                  </router-link>

                  <button>
                    <svg
                      class="w-6 h-6"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 4a2 2 0 012-2h6a2 2 0 012 2v14l-5-2.5L5 18V4z"
                        class="hover:text-red-300 cursor-pointer "
                      ></path>
                    </svg>
                  </button>

                  <button>
                    <svg
                      class="w-6 h-6"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z"
                        class="hover:text-blue-300 cursor-pointer "
                      ></path>
                    </svg>
                  </button>
                  <div>
                    44
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
          <div class="mx-2">
          <div
            class="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden md:max-w-3xl "
          >
            <div class="md:flex m-2 ">
              <div class="md:flex-shrink-0">
                <img
                  class="h-48 w-full object-cover md:h-full md:w-48 bg-green-100 rounded-md "
                  src="/programmer-animate.svg"
                  alt="hehe"
                />
              </div>
              <div class="flex flex-col  ">
                <div class="p-5">
                  <p
                    class="tracking-wide text-white px-2 py-1  flex justify-center items-center w-max bg-red-400 rounded-xl text-xs mb-5"
                  >
                    subject tag
                  </p>

                  <h3
                    href="#"
                    class="block mt-1 text-lg leading-tight font-medium text-black hover:underline"
                  >
                    Subject title
                  </h3>
                  <p class="mt-2 text-gray-500 max-w-prose">
                    Getting a new business off the ground is a lot of hard work.
                    Here are five ideas you can use to find your first
                    customers.
                  </p>
                </div>
                <div class="flex gap-4 justify-end  p-5 items-center">
                  <router-link to="/BlogPost"
                    class="bg-indigo-400 py-2 px-3 rounded-md shadow-md font-semibold text-white hover:bg-indigo-600"
                  >
                    Read More
                  </router-link>

                  <button>
                    <svg
                      class="w-6 h-6"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 4a2 2 0 012-2h6a2 2 0 012 2v14l-5-2.5L5 18V4z"
                        class="hover:text-red-300 cursor-pointer "
                      ></path>
                    </svg>
                  </button>

                  <button>
                    <svg
                      class="w-6 h-6"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z"
                        class="hover:text-blue-300 cursor-pointer "
                      ></path>
                    </svg>
                  </button>
                  <div>
                    44
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
          <div class="mx-2">
          <div
            class="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden md:max-w-3xl "
          >
            <div class="md:flex m-2 ">
              <div class="md:flex-shrink-0">
                <img
                  class="h-48 w-full object-cover md:h-full md:w-48 bg-green-100 rounded-md "
                  src="/programmer-animate.svg"
                  alt="hehe"
                />
              </div>
              <div class="flex flex-col  ">
                <div class="p-5">
                  <p
                    class="tracking-wide text-white px-2 py-1  flex justify-center items-center w-max bg-red-400 rounded-xl text-xs mb-5"
                  >
                    subject tag
                  </p>

                  <h3
                    href="#"
                    class="block mt-1 text-lg leading-tight font-medium text-black hover:underline"
                  >
                    Subject title
                  </h3>
                  <p class="mt-2 text-gray-500 max-w-prose">
                    Getting a new business off the ground is a lot of hard work.
                    Here are five ideas you can use to find your first
                    customers.
                  </p>
                </div>
                <div class="flex gap-4 justify-end  p-5 items-center">
                  <router-link to="/BlogPost"
                    class="bg-indigo-400 py-2 px-3 rounded-md shadow-md font-semibold text-white hover:bg-indigo-600"
                  >
                    Read More
                  </router-link>

                  <button>
                    <svg
                      class="w-6 h-6"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M5 4a2 2 0 012-2h6a2 2 0 012 2v14l-5-2.5L5 18V4z"
                        class="hover:text-red-300 cursor-pointer "
                      ></path>
                    </svg>
                  </button>

                  <button>
                    <svg
                      class="w-6 h-6"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z"
                        class="hover:text-blue-300 cursor-pointer "
                      ></path>
                    </svg>
                  </button>
                  <div>
                    44
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- show more  -->
      <div class="flex justify-center">
        <div
          class="px-8 py-3 bg-red-400 w-max rounded-md font-semibold text-white m-4 shadow-xl hover:bg-red-500 cursor-pointer"
        >
          Show More
        </div>
      </div>
    </div>
  </div>
</template>
