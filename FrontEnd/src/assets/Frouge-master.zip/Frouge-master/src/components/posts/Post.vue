<template>
  <div class="h-20"></div>
  <div class="flex gap-6 flex-col  mx-auto">
    <div class="px-16 mx-5 xl:mx-44">
      <h1 class="text-start text-5xl font-semibold mb-12 ">
        Lorem ipsum dolor sit amet consectetur adipisicing elit.
      </h1>
      <h2>RedOne</h2>
      <p class="text-sm">Posted at : 64/sep/2021</p>
    </div>
    <div class="">
      <img src="../../assets/science.png" alt="" class="bg" />
    </div>
    <div class="px-16">
      <p class="text-2xl mx-5 xl:mx-44 mt-4  text-start ">
        Lorem, ipsum dolor sit amet, consectetur adipisicing elit. Sint
        architecto sequi neque delectus maxime, vitae nobis excepturi nostrum
        magni doloremque similique facere ad illum provident dicta praesentium
        iure autem laborum. Accusamus adipisci temporibus hic sint odit neque id
        quod doloribus inventore obcaecati, perspiciatis culpa, tempora ad
        sapiente recusandae totam impedit voluptas mollitia illum laborum? Totam
        reiciendis cum fugiat adipisci repudiandae odit accusantium molestiae,
        distinctio molestias nostrum nesciunt. Voluptates magni similique velit
        nostrum quidem praesentium. Atque culpa sint dolorem corporis,
        consectetur sunt ab, rerum tempore voluptates deserunt, nostrum
        reprehenderit temporibus illum! Lorem ipsum dolor sit amet consectetur
        adipisicing elit. Cum modi ducimus porro officiis ab ratione magnam iure
        impedit consequatur aliquam atque nulla sit laborum aspernatur, minima
        eos suscipit ipsa enim. Lorem ipsum dolor sit amet consectetur,
        adipisicing elit. Odio tempora sunt id. Fugit rem ducimus nihil illum
        aliquid consequuntur odio eius nemo, molestiae, quo sequi reprehenderit
        nostrum, tenetur debitis maiores. Voluptate provident inventore aperiam
        magnam doloribus voluptates, exercitationem reiciendis qui cumque
        architecto recusandae odit, velit dolores, facilis nesciunt! Eligendi,
        iste?
      </p>
    </div>
    <div class=" h-4"></div>
    <div class="flex gap-6 justify-end px-16 ">
      <button>
        <svg
          class="w-6 h-6"
          fill="currentColor"
          viewBox="0 0 20 20"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z"
          ></path>
        </svg>
      </button>
      <button>
        <svg
          class="w-6 h-6"
          fill="currentColor"
          viewBox="0 0 20 20"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            fill-rule="evenodd"
            d="M18 13V5a2 2 0 00-2-2H4a2 2 0 00-2 2v8a2 2 0 002 2h3l3 3 3-3h3a2 2 0 002-2zM5 7a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1zm1 3a1 1 0 100 2h3a1 1 0 100-2H6z"
            clip-rule="evenodd"
          ></path>
        </svg>
      </button>
    </div>

    <div class="px-32 py-10 flex flex-col gap-4 bg-gray-100">
      <h1 class="font-semibold">Leave a Comment ..</h1>
      <textarea
        class=" w-96 h-14 border-2 border-gray-300 rounded-sm"
        name=""
        cols="30"
        rows="10"
      ></textarea>
      <button class="flex justify-start bg-gray-500 w-max p-2 text-white">
        Comment
      </button>

      <div class="px-10 ">
        <div class="bg-gray-200 p-2">
          <div class="flex gap-4 py-4 ">
            <img src="" alt="" class="w-5 h-5" />
            <h1>User</h1>
          </div>

          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum maiores
            illo cum dignissimos. Architecto, repellat? Commodi dolores possimus
            autem, facilis unde iste nemo asperiores est voluptatem quod
            aspernatur sint ipsum? lorem50
          </p>
        </div>
      </div>
    </div>
  </div>
</template>
<style scoped>
.bg {
  object-fit: cover;
  width: 100%;
  height: 350px;
}
</style>
