<template>
  <div
    class="flex justify-between gap-6 w-4/5 sm:w-11/12 md:w-11/12 xl:w-3/4  mx-auto "
  >
    <div class="flex mb-20 gap-5 flex-wrap w-full justify-center ">
      <div class="admin bg-red-400 flex-grow  p-6 ">
        <h1 class="text-xl font-bold text-white">Welcome Admin</h1>
      </div>

      <div class="">
        <div
          class="flex gap-4 justify-between
        items-center flex-wrap text-white "
        >
          <div class="  bg-indigo-500 p-4 rounded-md w-52">
            <h1 class="font-semibold">YouClub Members</h1>
            <h2>23432</h2>
          </div>
          <div class=" bg-indigo-500 p-4 rounded-md w-52">
            <h1 class="font-semibold">Posts Submited</h1>
            <h2>23432</h2>
          </div>
          <div class=" bg-indigo-500 p-4 rounded-md w-52">
            <h1 class="font-semibold">Posted in th last 24</h1>
            <h2>23432</h2>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div
    class="align-middle mx-auto w-4/5 sm:w-11/12 md:w-11/12 xl:w-3/4 shadow overflow-hidden sm:rounded-lg border-b border-gray-200"
  >
    <table class="w-full">
      <thead class="">
        <tr class="">
          <th
            class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider"
          >
            Name
          </th>
          <th
            class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider"
          >
            Title
          </th>
          <th
            class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider"
          >
            Role
          </th>
          <th
            class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-center text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider"
          >
            Action
          </th>
        </tr>
      </thead>

      <tbody class="bg-white">
        <tr class="">
          <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-200">
            <div class="flex items-center">
              <div class="flex-shrink-0 h-10 w-10">
                <img
                  class="h-10 w-10 rounded-full bg-green-400"
                  src=""
                  alt=""
                />
              </div>

              <div class="ml-4">
                <div class="text-sm leading-5 font-medium text-gray-900">
                  John Doe
                </div>
                <div class="text-sm leading-5 text-gray-500">
                  Red@baba.oi
                </div>
              </div>
            </div>
          </td>

          <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-200">
            <div class="text-sm leading-5 text-gray-900">dev</div>
            <div class="text-sm leading-5 text-gray-500">Web dev</div>
          </td>

          <td
            class="px-6 py-4 whitespace-no-wrap border-b border-gray-200 text-sm leading-5 text-gray-500"
          >
            Owner
          </td>

          <td
            class=" space-x-5  px-6 py-4 whitespace-no-wrap text-center border-b border-gray-200 text-sm leading-5 font-medium"
          >
            <button class="text-red-400 hover:text-red-500">
              <svg
                class="w-6 h-6"
                fill="currentColor"
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fill-rule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                  clip-rule="evenodd"
                ></path>
              </svg>
            </button>
             <button class="text-red-400 hover:text-red-500">
              <svg
                class="w-6 h-6"
                fill="currentColor"
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fill-rule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                  clip-rule="evenodd"
                ></path>
              </svg>
            </button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<style>
/* .admin{
  clip-path: polygon(5% 0%, 100% 0%, 95% 100%, 0% 100%);
} */

</style>