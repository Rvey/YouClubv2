<template>
  <section
    class="section overflow-hidden text-gray-600 body-font mt-32 md:mt-1 lg:mt-1 xl:mt-1"
  >
    <div
      class="container mx-auto flex px-5 pb-20 items-center justify-center flex-col "
    >
      <img
        class="lg:w-2/6 md:w-3/6 w-5/6 mb-10 object-cover object-center"
        alt="ehe"
        src="../../../assets/telework-animate.svg"
      />

      <div class="text-center lg:w-2/3 w-full">
        <h1
          class="title-font sm:text-4xl text-3xl mb-4 font-medium font-mont text-gray-900"
        >
          Lorem ipsum dolor sit.
        </h1>
        <p class="mb-8 leading-relaxed">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur
          minus saepe quaerat aliquid nemo maiores eaque nobis ex, accusamus
          esse?
        </p>
        <div class="flex justify-center">
          <button
            class="inline-flex text-white bg-red-500 border-0 py-2 px-6 focus:outline-none hover:bg-red-400 rounded text-lg z-10"
          >
            Discover new Topics
          </button>
        </div>
      </div>
    </div>
  </section>
</template>
<script>
export default {
  name: "hero",
  setup() {},
};
</script>

<style lang="scss"></style>
