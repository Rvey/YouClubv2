<template>
       <div class="flex flex-col text-center w-full mb-20">
        <h1 class=" text-5xl font-medium  text-gray-900">Why <span class="bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-blue-500 font-bold">YouClub</span> </h1>
      </div>

      <!-- why youclub -->
      <section class=" section2 text-gray-100 body-font bg-gradient-to-r from-red-400 to-indigo-500">
        <div class=" container mx-auto flex px-5 py-12  md:flex-row flex-col items-center">
        
          <div class="lg:flex-grow md:w-1/2 lg:pl-24 md:pl-16 flex flex-col md:items-start md:text-left items-center text-center">
            <h1 class="title-font sm:text-4xl text-3xl mb-4 font-medium text-gray-900">Before they sold out
              <br class="hidden lg:inline-block">readymade gluten
            </h1>
            <p class="mb-8 leading-relaxed">Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores illo accusantium eveniet, adipisci corporis aut necessitatibus repellat quas odit, quia corrupti doloribus, cumque autem itaque? Ut beatae ea excepturi cum?</p>
          </div>
          <div class="lg:max-w-lg lg:w-full md:w-1/2 w-5/6 mb-10 md:mb-0">
            <img class="object-cover object-center rounded" alt="hero" src="../../../../assets/shared-goals-animate.svg">
          </div>
        </div>
      </section>
      <section class="text-gray-600 body-font" >
      
        <div class="container mx-auto flex px-5 py-12 md:flex-row flex-col items-center">
          <div class="lg:max-w-lg lg:w-full md:w-1/2 w-5/6 mb-10 md:mb-0">
            <img class="transform motion-safe:hover:scale-110" alt="shared" src="../../../../assets/team-animate.svg">
          </div>
          <div class="lg:flex-grow md:w-1/2 lg:pl-24 md:pl-16 flex flex-col md:items-start md:text-left items-center text-center">
            <h1 class="title-font sm:text-4xl text-3xl mb-4 font-medium text-gray-900">Before they sold out
              <br class="hidden lg:inline-block">lorem ipsum
            </h1>
            <p class="mb-8 leading-relaxed">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Cumque, molestiae. Est ut a laboriosam. Doloribus reiciendis est corporis, doloremque accusamus minima, nostrum odit magnam totam molestiae sapiente deserunt ratione aut.</p>
           
          </div>
        </div>
      </section>
      <section class=" section2 text-gray-100 body-font bg-gradient-to-l from-red-400 to-indigo-500">
        <div class=" container mx-auto flex px-5 py-12  md:flex-row flex-col items-center">
        
          <div class="lg:flex-grow md:w-1/2 lg:pl-24 md:pl-16 flex flex-col md:items-start md:text-left items-center text-center">
            <h1 class="title-font sm:text-4xl text-3xl mb-4 font-medium text-gray-900">Before they sold out
              <br class="hidden lg:inline-block">readymade gluten
            </h1>
            <p class="mb-8 leading-relaxed">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Et iste nam qui in eum quaerat velit ducimus deleniti. Laudantium doloremque eius odit, aliquam reprehenderit ipsum sequi illum consectetur fuga cumque.</p>
          </div>
          <div class="lg:max-w-lg lg:w-full md:w-1/2 w-5/6 mb-10 md:mb-0">
            <img class="object-cover object-center rounded" alt="hero" src="../../../../assets/feedback-animate.svg">
          </div>
        </div>
      </section>
</template>
<script>
export default {
    name : 'problem',
    setup() {
        
    },
}
</script>