import { createRouter, createWebHashHistory } from 'vue-router'
import Home from '../views/Home.vue'
import Register from '../views/Register.vue'
import Community from '../views/Community.vue'
import Profile from '../views/Profile.vue'
import Dashboard from '../views/Dashboard.vue'
import Login from '../views/Login.vue'
import BlogPost from '../views/BlogPost.vue'
const routes = [

  { path: '/' , name: 'Home' , component: Home },

  { path: '/Login' , name: 'Login' , component: Login },

  { path: '/Register', name: 'Register' , component: Register },

  { path: '/Community' , name: 'Community' , component: Community},

  {path: '/Profile' , name: 'Profile', component: Profile },

  { path: '/Dashboard' , name: 'Dashboard' , component: Dashboard },

  { path: '/BlogPost' , name: 'BlogPost' , component: BlogPost },
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
