<template>
  <SpaceNav />
  <Whitespace/>
  <Dash/>
</template>

<script>
// @ is an alias to /src
import SpaceNav from "@/components/SpaceNav/SpaceNav.vue"
import Dash from '@/components/Dashboard/dashboard.vue'
import Whitespace from '@/components/Misc/Whitespace.vue'

export default {
  name: "Community",
  components: {
    SpaceNav,
    Dash,
    Whitespace
  },
};
</script>
