<template>
    <nav/>
    <FormReg/>
</template>

<script>
import Nav from '@/components/nav/nav.vue'
import FormReg from '@/components/form/formReg.vue'
export default {
  name: 'Register',
  components: {
    Nav,
    FormReg
  }
}
</script>
