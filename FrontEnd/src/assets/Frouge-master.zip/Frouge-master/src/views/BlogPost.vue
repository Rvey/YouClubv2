<template>
<Space-nav />
<Post />
 </template>

<script>
import SpaceNav from "@/components/SpaceNav/SpaceNav.vue"
import Post from "@/components/posts/Post.vue"
export default {
      components: {
    SpaceNav,
        Post

  },
    
            SpaceNavsetup() {
        
    },
}
</script>
