<template>
  <Modal v-if="modalOpen" :modalContent="modalContent" @close="handleClose()" />
  <SpaceNav />
  <Greeting />
  <Whitespace />
  <Cardposts />
</template>

<script>
// @ is an alias to /src
import SpaceNav from "@/components/SpaceNav/SpaceNav.vue";
import Cardposts from "@/components/posts/Cardposts.vue";
import Greeting from "@/components/Greeting/Greeting.vue";
import Whitespace from "@/components/Misc/Whitespace.vue";
import Modal from "@/components/Misc/Modal.vue";
import { ref } from "vue";
export default {
  name: "Community",
  components: {
    SpaceNav,
    Cardposts,
    Greeting,
    Whitespace,
    Modal,
  },
   setup() {
    const modalOpen = ref(false);
    const modalContent = ref("");

    const handleClose = () => {
      modalOpen.value = false;
    };

    const openModal = (modal) => {
      modalContent.value = modal;
      modalOpen.value = true  
    };
    const closeModal = (modal) => {
      modalContent.value = modal;
      modalOpen.value = false;
    }


    return {
      modalOpen,
      handleClose,
      openModal,
      modalContent,
    };
  },
};
</script>
