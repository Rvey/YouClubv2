<template>
  <SpaceNav />
  <Whitespace />
  <MyProfile />
</template>

<script>
// @ is an alias to /src
import SpaceNav from "@/components/SpaceNav/SpaceNav.vue";
import MyProfile from "@/components/Profile/Profile.vue";
import Whitespace from "@/components/Misc/Whitespace.vue";
export default {
  name: "Profile",
  components: {
    SpaceNav,
    MyProfile,
    Whitespace,
  },
};
</script>
