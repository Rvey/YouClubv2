<template >
  <Nav  />
  <Whitespace />
  <Hero />
  <Feature />
  <Problem />
  <Footer />
</template>

<script>
import Nav from "@/components/nav/nav.vue";
import Hero from "@/components/home/hero/hero.vue";
import Feature from "@/components/home/sections/feature/feature.vue";
import Problem from "@/components/home/sections/problem/problem.vue";
import Footer from "@/components/footer/footer.vue";
import Whitespace from "@/components/Misc/Whitespace.vue";
export default {
  name: "Home",
  components: {
    Nav,
    Hero,
    Feature,
    Problem,
    Footer,
    Whitespace,
  },
};
</script>
