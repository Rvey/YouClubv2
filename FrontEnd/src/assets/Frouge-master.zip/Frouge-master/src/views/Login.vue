<template>
    <Form/>
</template>

<script>
import Form from '@/components/form/form.vue'
export default {
  name: 'login',
  components: {
    Form
  }
}
</script>
