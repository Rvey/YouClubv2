module.exports = {
  mode: 'jit',
  purge: { content: ['./public/**/*.html', './src/**/*.vue'] },
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {
      fontFamily: {
        'karla': ['karla', 'sans-serif'],
        'krona': ['Krona One', 'sans-serif'],
        'mont': ['Montserrat' , 'sans-serif'],
        'inter':['Inter' , 'sans-serif'],
        'popp':['Poppins','sans-serif']
       }
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
